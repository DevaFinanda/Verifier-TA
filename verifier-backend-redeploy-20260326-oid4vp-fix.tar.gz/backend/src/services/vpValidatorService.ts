/**
 * VP Token Validator Service
 *
 * Implements manual verification of VP Token sesuai alur di OID4VP-Verifier-Flow.md:
 *
 * 9 Langkah Validasi:
 *  1. Decode VP JWT header
 *  2. Resolve holder DID → ambil public key
 *  3. Verifikasi tanda tangan VP (holder's key)
 *  4. Cek nonce — anti-replay attack
 *  5. Decode VC JWT → ambil issuer DID
 *  6. Resolve issuer DID → ambil publik key
 *  7. Verifikasi tanda tangan VC (issuer's key)
 *  8. Validasi klaim VC (nbf, exp, tipe, holder binding)
 *  9. Ekstrak required claims
 *
 * Format yang didukung:
 *  - jwt_vc_json  : W3C VP JWT berisi VC JWT (holder sign VP, issuer sign VC)
 *  - vc+sd-jwt    : SD-JWT dengan Key Binding JWT (format yang digunakan Credo-TS)
 *
 * Dependensi (sudah tersedia):
 *  - jsonwebtoken  : JWT decode (already installed)
 *  - Node.js crypto: Ed25519 signature verification (built-in, no extra package)
 *  - Credo Agent   : DID resolver via agent.dids.resolve(did)
 */

import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { getCredoAgent, BPJS_PRESENTATION_DEFINITION } from '../credo-verifier.js';
import { getIssuerByDid } from '../config/trustedIssuers.js';
import { config } from '../config/index.js';
import { didCache, type DIDDocument as CachedDIDDocument } from '../utils/didCache.js';
import { resolveDidWithCache } from '../utils/didResolverWithCache.js';
import type { VerificationCheck, VerificationOutcome, VerificationReasonCode } from '../types/verification.js';
import { validateDescriptorMap } from './descriptorValidationService.js';
import { enforceDisclosurePolicy, parseClaimKeysFromDefinition, verifierPolicy } from './policyEngine.js';
import { parseDisclosureToken, SdJwtDisclosureError, verifyDisclosures } from './sdJwtDisclosureService.js';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface VerifiedBPJSClaims {
  holderDID: string;
  issuerDID: string;
  holderName?: string;
  noBPJS?: string;
  nik?: string;
  tanggalLahir?: string;
  statusKepesertaan?: string;
  issuedAt?: number;
  expiresAt?: number;
  [key: string]: unknown;
}

export interface VerifiedPresentationResult {
  claims: VerifiedBPJSClaims;
  outcome: VerificationOutcome;
}

export class VPValidationError extends Error {
  constructor(message: string, public step?: string) {
    super(message);
    this.name = 'VPValidationError';
  }
}

interface CredentialStatusCacheEntry {
  status: string;
  checkedAt: number;
}

const credentialStatusCache = new Map<string, CredentialStatusCacheEntry>();
const CREDENTIAL_STATUS_CACHE_MS = 5 * 60 * 1000;

function buildOutcome(checks: VerificationCheck[]): VerificationOutcome {
  const reasonCodes = checks
    .filter((check) => !check.passed && check.reasonCode)
    .map((check) => check.reasonCode as VerificationReasonCode);

  const cryptographicVerified = !checks.some(
    (check) =>
      !check.passed
      && ['signature_vp', 'signature_vc', 'did_resolution_holder', 'did_resolution_issuer', 'algorithm_policy'].includes(check.name),
  );

  const issuerTrusted = !checks.some((check) => !check.passed && check.name === 'issuer_trust');
  const statusValid = !checks.some((check) => !check.passed && check.name === 'credential_status');
  const claimValid = !checks.some(
    (check) =>
      !check.passed
      && ['mandatory_fields', 'credential_type', 'holder_binding', 'presentation_submission', 'audience', 'nonce'].includes(check.name),
  );

  const failedLayer = resolveFailedLayer(reasonCodes);

  return {
    cryptographicVerified,
    issuerTrusted,
    statusValid,
    claimValid,
    overallVerified: checks.every((check) => check.passed),
    failedLayer,
    reasonCodes,
    checks,
  };
}

function resolveFailedLayer(reasonCodes: VerificationReasonCode[]): VerificationOutcome['failedLayer'] {
  if (reasonCodes.length === 0) return null;
  if (reasonCodes.some((code) => ['invalid_request', 'missing_vp_token', 'missing_state'].includes(code))) return 'REQUEST';
  if (reasonCodes.some((code) => ['invalid_state', 'session_already_used', 'session_expired', 'replay_detected'].includes(code))) return 'SESSION';
  if (reasonCodes.some((code) => ['presentation_definition_mismatch', 'descriptor_path_invalid', 'descriptor_credential_mismatch'].includes(code))) return 'DESCRIPTOR';
  if (reasonCodes.some((code) => ['disclosure_hash_mismatch', 'disclosure_format_invalid'].includes(code))) return 'DISCLOSURE';
  if (reasonCodes.some((code) => ['invalid_proof', 'issuer_signature_invalid', 'unsupported_algorithm', 'key_binding_invalid'].includes(code))) return 'CRYPTOGRAPHIC';
  if (reasonCodes.some((code) => ['missing_required_claim', 'oversharing_detected', 'invalid_credential_structure', 'holder_binding_invalid', 'invalid_nonce', 'invalid_audience', 'nonce_missing_in_proof'].includes(code))) return 'POLICY';
  if (reasonCodes.includes('issuer_not_trusted')) return 'TRUST';
  if (reasonCodes.some((code) => ['credential_revoked', 'credential_suspended', 'credential_expired', 'credential_status_unavailable'].includes(code))) return 'STATUS';
  return 'PRESENTATION';
}

export function mapStepToReasonCode(step?: string, message?: string): VerificationReasonCode {
  const stepOrMessage = `${step || ''} ${message || ''}`.toLowerCase();
  if (stepOrMessage.includes('descriptor_path')) return 'descriptor_path_invalid';
  if (stepOrMessage.includes('descriptor_credential')) return 'descriptor_credential_mismatch';
  if (stepOrMessage.includes('missing_required_claim')) return 'missing_required_claim';
  if (stepOrMessage.includes('oversharing')) return 'oversharing_detected';
  if (stepOrMessage.includes('disclosure_hash')) return 'disclosure_hash_mismatch';
  if (stepOrMessage.includes('disclosure_format')) return 'disclosure_format_invalid';
  if (stepOrMessage.includes('key_binding')) return 'key_binding_invalid';
  if (stepOrMessage.includes('replay')) return 'replay_detected';
  if (stepOrMessage.includes('nonce_missing_in_proof')) return 'nonce_missing_in_proof';
  if (stepOrMessage.includes('nonce')) return 'invalid_nonce';
  if (stepOrMessage.includes('aud')) return 'invalid_audience';
  if (stepOrMessage.includes('revok')) return 'credential_revoked';
  if (stepOrMessage.includes('suspend')) return 'credential_suspended';
  if (stepOrMessage.includes('expired') || stepOrMessage.includes('exp')) return 'credential_expired';
  if (stepOrMessage.includes('untrusted_issuer')) return 'issuer_not_trusted';
  if (stepOrMessage.includes('signature')) return 'issuer_signature_invalid';
  if (stepOrMessage.includes('holder_binding')) return 'holder_binding_invalid';
  if (stepOrMessage.includes('vc_type') || stepOrMessage.includes('presentation')) return 'presentation_definition_mismatch';
  if (stepOrMessage.includes('did_resolution') || stepOrMessage.includes('proof')) return 'invalid_proof';
  if (stepOrMessage.includes('algorithm')) return 'unsupported_algorithm';
  if (stepOrMessage.includes('credential_status')) return 'credential_status_unavailable';
  if (stepOrMessage.includes('credential_structure') || stepOrMessage.includes('mandatory')) {
    return 'invalid_credential_structure';
  }
  return 'unknown_error';
}

function parseCredentialStatus(responsePayload: unknown): string | null {
  if (!responsePayload || typeof responsePayload !== 'object') return null;
  const payload = responsePayload as Record<string, unknown>;
  const directStatus = payload.status ?? payload.state ?? payload.credentialStatus;

  if (typeof directStatus === 'string') return directStatus.toUpperCase();
  if (directStatus && typeof directStatus === 'object') {
    const nested = directStatus as Record<string, unknown>;
    if (typeof nested.status === 'string') return nested.status.toUpperCase();
    if (typeof nested.state === 'string') return nested.state.toUpperCase();
  }
  return null;
}

async function fetchCredentialStatusOnline(
  statusId: string,
  issuerEndpoint?: string,
): Promise<string> {
  const sources = [statusId];
  if (issuerEndpoint) {
    const base = issuerEndpoint.replace(/\/$/, '');
    sources.push(`${base}/api/credential-status?id=${encodeURIComponent(statusId)}`);
    sources.push(`${base}/credential-status?id=${encodeURIComponent(statusId)}`);
  }

  for (const source of sources) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    try {
      const res = await fetch(source, {
        headers: { Accept: 'application/json' },
        signal: controller.signal,
      });
      if (!res.ok) continue;
      const payload = (await res.json()) as unknown;
      const status = parseCredentialStatus(payload);
      if (status) {
        credentialStatusCache.set(statusId, { status, checkedAt: Date.now() });
        return status;
      }
    } catch {
      // try next source or fallback cache
    } finally {
      clearTimeout(timeout);
    }
  }

  const cached = credentialStatusCache.get(statusId);
  if (verifierPolicy.allowStatusCacheFallback && cached && Date.now() - cached.checkedAt <= CREDENTIAL_STATUS_CACHE_MS) {
    return cached.status;
  }
  throw new VPValidationError('Credential status endpoint tidak tersedia', 'CREDENTIAL_STATUS_UNAVAILABLE');
}

// ─── DID Resolver (via Credo agent) ──────────────────────────────────────────

/**
 * Ekstrak crypto.KeyObject dari satu verificationMethod DID Document.
 * Mendukung publicKeyJwk, publicKeyMultibase (did:key z-prefix), dan publicKeyBase58.
 */
function extractKeyFromVM(vm: Record<string, unknown>, did: string): crypto.KeyObject {
  // Case 1: publicKeyJwk (OKP Ed25519 / JsonWebKey2020)
  if (vm.publicKeyJwk) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return crypto.createPublicKey({ format: 'jwk', key: vm.publicKeyJwk as any });
  }

  // Case 2: publicKeyMultibase (did:key — z prefix = base58btc)
  // Format: z + base58btc( 0xed 0x01 + 32-byte Ed25519 raw public key )
  if (typeof vm.publicKeyMultibase === 'string' && vm.publicKeyMultibase.startsWith('z')) {
    const rawKey = base58Decode(vm.publicKeyMultibase.slice(1)).slice(2); // skip 0xed 0x01 multicodec prefix
    return crypto.createPublicKey({
      key: { kty: 'OKP', crv: 'Ed25519', x: Buffer.from(rawKey).toString('base64url') },
      format: 'jwk',
    });
  }

  // Case 3: publicKeyBase58 (Ed25519VerificationKey2018 — format lama W3C)
  if (typeof vm.publicKeyBase58 === 'string') {
    const rawKey = base58Decode(vm.publicKeyBase58);
    return crypto.createPublicKey({
      key: { kty: 'OKP', crv: 'Ed25519', x: Buffer.from(rawKey).toString('base64url') },
      format: 'jwk',
    });
  }

  throw new VPValidationError(`Format public key tidak dikenali di DID: ${did}`, 'DID_RESOLUTION');
}

/**
 * Cari verificationMethod di DID Document yang cocok dengan `kid`.
 * Gunakan exact match pada field `id`, lalu fallback ke kecocokan fragmen (#key-id).
 * Jika kid disediakan namun tidak cocok, verification harus gagal.
 */
function findVerificationMethodByKid(
  vms: Array<Record<string, unknown>>,
  kid?: string,
): Record<string, unknown> {
  if (kid) {
    // Exact match: VM id === kid (e.g. "did:web:202.155.132.71#key-1")
    const exact = vms.find(vm => vm.id === kid);
    if (exact) return exact;
    // Fragment-only match: cari VM yang id-nya berakhir dengan "#<fragment>"
    const fragment = kid.includes('#') ? kid.split('#')[1] : undefined;
    if (fragment) {
      const byFragment = vms.find(
        vm => typeof vm.id === 'string' && (vm.id as string).endsWith(`#${fragment}`),
      );
      if (byFragment) return byFragment;
    }
      throw new VPValidationError(
        `Verification method dengan kid="${kid}" tidak ditemukan`,
        'KID_MISMATCH',
      );
  }
  return vms[0];
}

/**
 * Resolve DID Document dan kembalikan crypto.KeyObject Ed25519.
 *
 * Urutan resolusi dengan cache berlapis:
 *  1. Credo Agent    — resolver bawaan (KeyDidResolver, WebDidResolver, JwkDidResolver)
 *                      → jika berhasil, DID Document disimpan ke cache lokal
 *  2. Cache + Network — resolveDidWithCache() menangani:
 *                       a. Cache hit (TTL valid)     → "DID loaded from cache"
 *                       b. Network fetch berhasil    → "DID resolved from network"
 *                       c. Network down, stale cache → "DID fallback from cache"
 *
 * @param did  DID issuer/holder (e.g. "did:web:202.155.132.71")
 * @param kid  Key ID dari JWT header — untuk memilih verificationMethod yang tepat
 */
async function resolveDIDPublicKey(did: string, kid?: string): Promise<crypto.KeyObject> {
  // ── Path 1: Credo agent (standard DID resolver) ──────────────────────────
  try {
    const agent = getCredoAgent();
    const result = await agent.dids.resolve(did);

    if (result.didDocument) {
      const vms = result.didDocument.verificationMethod;
      if (!vms || vms.length === 0) {
        throw new VPValidationError(`Tidak ada verification method di DID: ${did}`, 'DID_RESOLUTION');
      }
      // Simpan ke cache → tersedia sebagai fallback jika server down nanti
      await didCache.init();
      await didCache.set(did, result.didDocument as unknown as CachedDIDDocument);
      const vm = findVerificationMethodByKid(vms as unknown as Array<Record<string, unknown>>, kid);
      return extractKeyFromVM(vm, did);
    }
  } catch (credoErr) {
    if (credoErr instanceof VPValidationError) throw credoErr;
    if (did.startsWith('did:web:')) {
      console.warn(`⚠️  Credo DID resolver gagal untuk ${did}: ${(credoErr as Error).message}`);
    } else {
      throw new VPValidationError(
        `DID resolution gagal untuk ${did}: ${(credoErr as Error).message}`,
        'DID_RESOLUTION',
      );
    }
  }

  if (did.startsWith('did:web:')) {
    // ── Path 2 & 3: Cache-backed resolution (network + stale fallback) ───────
    // resolveDidWithCache menangani: cache hit → network → stale fallback
    try {
      const didDoc = await resolveDidWithCache(did);
      const vms = didDoc.verificationMethod;
      if (!vms?.length) {
        throw new VPValidationError(`Tidak ada verification method di DID: ${did}`, 'DID_RESOLUTION');
      }
      // Periksa assertionMethod (W3C spec)
      if (kid && (didDoc.assertionMethod as Array<unknown> | undefined)?.length) {
        const assertions = didDoc.assertionMethod as Array<string | Record<string, unknown>>;
        const inAssert = assertions.some(
          am => am === kid || (typeof am === 'object' && (am as Record<string, unknown>).id === kid),
        );
        if (!inAssert) {
          console.warn(`⚠️  kid="${kid}" tidak ditemukan di assertionMethod DID Document`);
        }
      }
      const vm = findVerificationMethodByKid(vms as unknown as Array<Record<string, unknown>>, kid);
      return extractKeyFromVM(vm, did);
    } catch (resolveErr) {
      if (resolveErr instanceof VPValidationError) throw resolveErr;
      throw new VPValidationError(
        `DID resolution gagal untuk ${did}: ${(resolveErr as Error).message}`,
        'DID_RESOLUTION',
      );
    }
  }

  throw new VPValidationError(`Tidak dapat resolve DID: ${did}`, 'DID_RESOLUTION');
}

// ─── Base58 Decoder (tanpa dependensi eksternal) ─────────────────────────────

const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

function base58Decode(str: string): Uint8Array {
  let num = BigInt(0);
  for (const ch of str) {
    const idx = BASE58_ALPHABET.indexOf(ch);
    if (idx < 0) throw new VPValidationError(`Karakter base58 tidak valid: ${ch}`, 'BASE58');
    num = num * BigInt(58) + BigInt(idx);
  }
  const hex = num.toString(16).padStart(2, '0');
  return new Uint8Array(Buffer.from(hex.length % 2 ? '0' + hex : hex, 'hex'));
}

// ─── JWT Ed25519 Signature Verifier ──────────────────────────────────────────

/**
 * Verifikasi tanda tangan Ed25519 pada JWT menggunakan Node.js crypto.
 * Returns decoded payload jika valid, throw VPValidationError jika tidak.
 */
async function verifyJWTSignature(
  token: string,
  publicKey: crypto.KeyObject,
): Promise<Record<string, unknown>> {
  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new VPValidationError('Format JWT tidak valid (harus 3 bagian)', 'JWT_FORMAT');
  }

  const [headerB64, payloadB64, signatureB64] = parts;
  const message = Buffer.from(`${headerB64}.${payloadB64}`);
  const signature = Buffer.from(signatureB64, 'base64url');

  const isValid = crypto.verify(null, message, publicKey, signature);
  if (!isValid) {
    throw new VPValidationError('Verifikasi tanda tangan JWT gagal', 'SIGNATURE_INVALID');
  }

  const payloadJson = Buffer.from(payloadB64, 'base64url').toString('utf-8');
  return JSON.parse(payloadJson) as Record<string, unknown>;
}

// ─── Format Detection ─────────────────────────────────────────────────────────

function detectFormat(vpToken: string): 'sd-jwt' | 'jwt_vc' {
  return vpToken.includes('~') ? 'sd-jwt' : 'jwt_vc';
}

function normalizeDomain(didOrDomain: string): string {
  if (!didOrDomain) return '';

  const noScheme = didOrDomain.replace(/^https?:\/\//i, '');
  const noDidPrefix = noScheme.startsWith('did:web:') ? noScheme.slice('did:web:'.length) : noScheme;
  return noDidPrefix.split('/')[0].trim().toLowerCase();
}

function audienceMatchesExpected(aud: unknown, expectedValues: string[]): boolean {
  if (typeof aud !== 'string') return false;
  const normalizedAud = normalizeDomain(aud);
  return expectedValues.some(
    (expected) => aud === expected || normalizedAud === normalizeDomain(expected),
  );
}

function extractCredentialSubjectFromJwtPayload(vcPayload: Record<string, unknown>): Record<string, unknown> | undefined {
  const nested = (vcPayload.vc as Record<string, unknown> | undefined)?.credentialSubject;
  if (nested && typeof nested === 'object') return nested as Record<string, unknown>;

  const direct = vcPayload.credentialSubject;
  if (direct && typeof direct === 'object') return direct as Record<string, unknown>;

  return undefined;
}

// ─── SD-JWT Parser ────────────────────────────────────────────────────────────

interface ParsedSdJwt {
  issuerJwt: string;
  kbJwt: string | null;
  disclosureTokens: string[];
}

function parseSdJwt(sdJwt: string): ParsedSdJwt {
  const parts = sdJwt.split('~');
  const issuerJwt = parts[0];
  let kbJwt: string | null = null;
  const disclosureTokens: string[] = [];

  for (let i = 1; i < parts.length; i++) {
    const part = parts[i];
    if (!part) continue;
    if (part.includes('.')) {
      kbJwt = part; // Key Binding JWT has dots
    } else {
      disclosureTokens.push(part);
    }
  }

  return { issuerJwt, kbJwt, disclosureTokens };
}

// ─── Main Entry Point ─────────────────────────────────────────────────────────

/**
 * Verifikasi VP Token sesuai flow MD — mendukung jwt_vc_json dan vc+sd-jwt.
 *
 * @param vpToken              String VP Token dari holder wallet
 * @param expectedNonce        Nonce dari sesi verifikasi yang dibuat verifier
 * @param presentationSubmission  (opsional) descriptor mapping
 */
export async function verifyVPToken(
  vpToken: string,
  expectedNonce: string,
  presentationSubmission?: unknown,
  presentationDefinition: unknown = BPJS_PRESENTATION_DEFINITION,
): Promise<VerifiedPresentationResult> {
  const format = detectFormat(vpToken);
  console.log(`  🔍 VP Token format detected: ${format}`);

  if (format === 'sd-jwt') {
    return verifySDJwtVP(vpToken, expectedNonce, presentationSubmission, presentationDefinition);
  }
  return verifyJwtVcVP(vpToken, expectedNonce, presentationSubmission, presentationDefinition);
}

// ─── Path A: jwt_vc_json (W3C VP JWT) ────────────────────────────────────────

async function verifyJwtVcVP(
  vpToken: string,
  expectedNonce: string,
  presentationSubmission?: unknown,
  presentationDefinition: unknown = BPJS_PRESENTATION_DEFINITION,
): Promise<VerifiedPresentationResult> {
  const checks: VerificationCheck[] = [];
  // ── STEP 1: Decode VP JWT header ──
  const rawDecoded = jwt.decode(vpToken, { complete: true });
  if (!rawDecoded) throw new VPValidationError('Tidak dapat decode VP JWT', 'STEP1_DECODE');
  if (!verifierPolicy.allowedAlgorithms.includes(rawDecoded.header.alg as string)) {
    throw new VPValidationError(`Algoritma tidak diizinkan: ${rawDecoded.header.alg as string}`, 'ALGORITHM_POLICY');
  }
  checks.push({ name: 'algorithm_policy', passed: true, message: 'VP algorithm is allowed' });

  // Ambil kid dari header VP JWT (e.g. "did:web:202.155.132.71#key-1")
  const vpKid = rawDecoded.header.kid;
  const vpPayloadRaw = rawDecoded.payload as Record<string, unknown>;

  // ── STEP 2: Resolve holder DID → ambil public key ──
  const holderDID = vpPayloadRaw.iss as string;
  if (!holderDID?.startsWith('did:')) {
    throw new VPValidationError('VP JWT tidak memiliki issuer DID yang valid', 'STEP2_HOLDER_DID');
  }

  const holderPublicKey = await resolveDIDPublicKey(holderDID, vpKid);
  checks.push({ name: 'did_resolution_holder', passed: true, message: 'Holder DID resolved' });

  // ── STEP 3: Verifikasi tanda tangan VP (holder's key) ──
  const vpPayload = await verifyJWTSignature(vpToken, holderPublicKey);
  checks.push({ name: 'signature_vp', passed: true, message: 'VP signature valid' });

  // ── STEP 4: Cek nonce — anti-replay attack ──
  if (verifierPolicy.requireNonceBinding && typeof vpPayload.nonce !== 'string') {
    throw new VPValidationError('Nonce tidak ditemukan pada VP proof', 'NONCE_MISSING_IN_PROOF');
  }
  if (vpPayload.nonce !== expectedNonce) {
    throw new VPValidationError(
      `Nonce tidak cocok: expected=${expectedNonce}, got=${vpPayload.nonce}`,
      'STEP4_NONCE_MISMATCH',
    );
  }
  checks.push({ name: 'nonce', passed: true, message: 'Nonce matches request' });

  // ── STEP 4b: Cek audience ──
  // VP audience harus verifier client_id — opsional jika tidak disertakan wallet
  // (tidak throw, hanya log)
  if (verifierPolicy.requireAudienceMatch) {
    const expectedAudience = config.oid4vp.verifierClientId;
    const expectedCandidates = [expectedAudience, config.did.verifierId, config.did.domain];
    if (!audienceMatchesExpected(vpPayload.aud, expectedCandidates)) {
      throw new VPValidationError(
        `Audience tidak valid: expected=${expectedAudience}, got=${String(vpPayload.aud)}`,
        'STEP4_AUDIENCE_MISMATCH',
      );
    }
    checks.push({ name: 'audience', passed: true, message: 'Audience matches verifier client_id' });
  } else {
    checks.push({ name: 'audience', passed: true, message: 'Audience check skipped by policy' });
  }

  // ── STEP 4c: Ekstrak VP → ambil VC JWT ──
  const vp = vpPayload.vp as Record<string, unknown> | undefined;
  const vcArray = vp?.verifiableCredential as string[] | undefined;
  if (!vcArray?.length) {
    throw new VPValidationError('VP tidak mengandung Verifiable Credential', 'STEP4_NO_VC');
  }
  if (verifierPolicy.requireDescriptorMapValidation) {
    const descriptorResult = validateDescriptorMap(presentationDefinition, presentationSubmission, vpPayload);
    if (!descriptorResult.ok) {
      const firstReason = descriptorResult.reasonCodes[0] || 'presentation_definition_mismatch';
      throw new VPValidationError('Descriptor map tidak valid terhadap presentation definition', firstReason.toUpperCase());
    }
    checks.push({ name: 'presentation_submission', passed: true, message: 'Descriptor map valid' });
  } else {
    checks.push({ name: 'presentation_submission', passed: true, message: 'Descriptor validation skipped by policy' });
  }
  const vcJwt = vcArray[0];

  // ── STEP 5: Decode VC JWT → ambil issuer DID dan kid ──
  const rawVC = jwt.decode(vcJwt, { complete: true });
  if (!rawVC) throw new VPValidationError('Tidak dapat decode VC JWT', 'STEP5_VC_DECODE');
  if (!verifierPolicy.allowedAlgorithms.includes(rawVC.header.alg as string)) {
    throw new VPValidationError(`Algoritma VC tidak diizinkan: ${rawVC.header.alg as string}`, 'ALGORITHM_POLICY');
  }

  // Ambil kid dari header VC JWT untuk menemukan kunci issuer yang tepat
  const vcKid = rawVC.header.kid;
  const vcPayloadRaw = rawVC.payload as Record<string, unknown>;
  const issuerDID = vcPayloadRaw.iss as string;
  if (!issuerDID?.startsWith('did:')) {
    throw new VPValidationError('VC tidak memiliki issuer DID yang valid', 'STEP5_ISSUER_DID');
  }

  // ── STEP 5.5: Verifikasi issuer terdaftar di trust anchor (W3C Trust Model) ──
  // Verifier WAJIB menolak VC dari issuer yang tidak dikenal — DIF/OID4VP requirement
  const trustedIssuerRecord = await getIssuerByDid(issuerDID);
  if (!trustedIssuerRecord) {
    throw new VPValidationError(
      `Issuer tidak terdaftar sebagai trusted issuer: ${issuerDID}`,
      'STEP5_UNTRUSTED_ISSUER',
    );
  }
  console.log(`  ✅ Issuer terverifikasi di trust anchor: ${trustedIssuerRecord.name}`);
  checks.push({ name: 'issuer_trust', passed: true, message: 'Issuer is in trusted whitelist' });

  // ── STEP 6: Resolve issuer DID → ambil public key (gunakan kid dari header VC JWT) ──
  const issuerPublicKey = await resolveDIDPublicKey(issuerDID, vcKid);
  checks.push({ name: 'did_resolution_issuer', passed: true, message: 'Issuer DID resolved' });

  // ── STEP 7: Verifikasi tanda tangan VC (issuer's key) ──
  const vcPayload = await verifyJWTSignature(vcJwt, issuerPublicKey);
  checks.push({ name: 'signature_vc', passed: true, message: 'VC signature valid' });

  // ── STEP 8: Validasi klaim VC ──
  const now = Math.floor(Date.now() / 1000);
  const skew = verifierPolicy.maxClockSkewSeconds;

  if (typeof vcPayload.nbf === 'number' && vcPayload.nbf > now + skew) {
    throw new VPValidationError('VC belum berlaku (nbf belum tercapai)', 'STEP8_NBF');
  }
  if (typeof vcPayload.exp === 'number' && vcPayload.exp < now - skew) {
    throw new VPValidationError('VC sudah kadaluarsa (exp)', 'STEP8_EXPIRED');
  }
  checks.push({ name: 'time_window', passed: true, message: 'VC nbf/exp valid' });

  const vc = (vcPayload.vc as Record<string, unknown> | undefined) ?? vcPayload;
  const typeRaw = vc?.type as string[] | string | undefined;
  const typeArr = Array.isArray(typeRaw) ? typeRaw : (typeof typeRaw === 'string' ? [typeRaw] : undefined);
  const acceptedTypes = ['BPJSHealthCredential', 'IdentityCredential', 'VerifiableCredential'];
  if (!typeArr?.some(t => acceptedTypes.includes(t))) {
    throw new VPValidationError(`Tipe VC tidak dikenali: ${typeArr?.join(', ')}`, 'STEP8_VC_TYPE');
  }
  checks.push({ name: 'credential_type', passed: true, message: 'Credential type accepted' });

  // Holder binding: sub di VC harus sama dengan iss di VP
  if (vcPayload.sub && vcPayload.sub !== holderDID) {
    throw new VPValidationError(
      `Holder binding gagal: VC sub=${vcPayload.sub} ≠ VP iss=${holderDID}`,
      'STEP8_HOLDER_BINDING',
    );
  }
  checks.push({ name: 'holder_binding', passed: true, message: 'Holder binding valid' });

  // Mandatory structure validation
  const credentialStatus = vc?.credentialStatus as Record<string, unknown> | undefined;
  const subject = extractCredentialSubjectFromJwtPayload(vcPayload);
  if (!issuerDID || !subject?.id || (!vcPayload.nbf && !vcPayload.iat) || !vcPayload.exp || !typeArr?.length || !credentialStatus?.id) {
    throw new VPValidationError('Field mandatory VC tidak lengkap', 'CREDENTIAL_STRUCTURE');
  }
  checks.push({ name: 'mandatory_fields', passed: true, message: 'Mandatory VC fields present' });

  const statusValue = await fetchCredentialStatusOnline(
    String(credentialStatus.id),
    trustedIssuerRecord.endpoint,
  );
  if (statusValue === 'REVOKED') {
    throw new VPValidationError('Credential telah direvoke', 'CREDENTIAL_STATUS_REVOKED');
  }
  if (statusValue === 'SUSPENDED') {
    throw new VPValidationError('Credential sedang disuspend', 'CREDENTIAL_STATUS_SUSPENDED');
  }
  if (statusValue === 'EXPIRED') {
    throw new VPValidationError('Credential status endpoint menyatakan expired', 'CREDENTIAL_STATUS_EXPIRED');
  }
  checks.push({ name: 'credential_status', passed: true, message: `Credential status is ${statusValue}` });

  // ── STEP 9: Ekstrak required claims ──
  const subjectForClaims = extractCredentialSubjectFromJwtPayload(vcPayload);
  if (!subjectForClaims) throw new VPValidationError('VC tidak memiliki credentialSubject', 'STEP9_NO_SUBJECT');

  const claims: VerifiedBPJSClaims = {
    holderDID,
    issuerDID,
    holderName: ((subjectForClaims.holderName ?? subjectForClaims.nama ?? subjectForClaims.name) as string | undefined),
    noBPJS: subjectForClaims.noBPJS as string | undefined,
    nik: subjectForClaims.nik as string | undefined,
    tanggalLahir: ((subjectForClaims.tanggalLahir ?? subjectForClaims.tanggal_lahir) as string | undefined),
    statusKepesertaan: subjectForClaims.statusKepesertaan as string | undefined,
    issuedAt: vcPayload.nbf as number | undefined,
    expiresAt: vcPayload.exp as number | undefined,
  };

  const requiredClaimSet = parseClaimKeysFromDefinition(presentationDefinition);
  const disclosurePolicy = enforceDisclosurePolicy(requiredClaimSet, subjectForClaims, verifierPolicy, 'jwt-vc');
  if (!disclosurePolicy.ok) {
    if (disclosurePolicy.missing.length > 0) {
      throw new VPValidationError(
        `Missing required claim: ${disclosurePolicy.missing.join(', ')}`,
        'MISSING_REQUIRED_CLAIM',
      );
    }

    if (disclosurePolicy.extras.length > 0) {
      throw new VPValidationError(
        `Oversharing claim terdeteksi: ${disclosurePolicy.extras.join(', ')}`,
        'OVERSHARING_DETECTED',
      );
    }
  }
  checks.push({ name: 'claim_policy', passed: true, message: 'Disclosure policy passed for JWT VC fallback' });

  return { claims, outcome: buildOutcome(checks) };
}

// ─── Path B: vc+sd-jwt (SD-JWT VP Token) ─────────────────────────────────────

async function verifySDJwtVP(
  sdJwtVP: string,
  expectedNonce: string,
  presentationSubmission?: unknown,
  presentationDefinition: unknown = BPJS_PRESENTATION_DEFINITION,
): Promise<VerifiedPresentationResult> {
  const checks: VerificationCheck[] = [];
  const { issuerJwt, kbJwt, disclosureTokens } = parseSdJwt(sdJwtVP);

  const syntheticVpPayload: Record<string, unknown> = {
    vp: {
      verifiableCredential: [sdJwtVP],
    },
  };

  if (verifierPolicy.requireDescriptorMapValidation) {
    const descriptorResult = validateDescriptorMap(presentationDefinition, presentationSubmission, syntheticVpPayload);
    if (!descriptorResult.ok) {
      const firstReason = descriptorResult.reasonCodes[0] || 'presentation_definition_mismatch';
      throw new VPValidationError('Descriptor map tidak valid terhadap presentation definition', firstReason.toUpperCase());
    }
    checks.push({ name: 'presentation_submission', passed: true, message: 'Descriptor map valid' });
  } else {
    checks.push({ name: 'presentation_submission', passed: true, message: 'Descriptor validation skipped by policy' });
  }

  // ── STEP 5: Decode issuer JWT → ambil issuer DID dan kid ──
  const rawIssuer = jwt.decode(issuerJwt, { complete: true });
  if (!rawIssuer) throw new VPValidationError('Tidak dapat decode SD-JWT issuer part', 'SD_JWT_DECODE');
  if (!verifierPolicy.allowedAlgorithms.includes(rawIssuer.header.alg as string)) {
    throw new VPValidationError(`Algoritma SD-JWT tidak diizinkan: ${rawIssuer.header.alg as string}`, 'ALGORITHM_POLICY');
  }
  checks.push({ name: 'algorithm_policy', passed: true, message: 'SD-JWT algorithm is allowed' });

  // Ambil kid dari header issuer JWT untuk menemukan kunci issuer yang tepat
  const issuerKid = rawIssuer.header.kid;
  const issuerPayloadRaw = rawIssuer.payload as Record<string, unknown>;
  const issuerDID = issuerPayloadRaw.iss as string;
  if (!issuerDID?.startsWith('did:')) {
    throw new VPValidationError('SD-JWT tidak memiliki issuer DID yang valid', 'SD_ISSUER_DID');
  }

  // ── STEP 5.5: Verifikasi issuer terdaftar di trust anchor (W3C Trust Model) ──
  const trustedIssuerRecord = await getIssuerByDid(issuerDID);
  if (!trustedIssuerRecord) {
    throw new VPValidationError(
      `Issuer tidak terdaftar sebagai trusted issuer: ${issuerDID}`,
      'SD_UNTRUSTED_ISSUER',
    );
  }
  console.log(`  ✅ Issuer terverifikasi di trust anchor: ${trustedIssuerRecord.name}`);
  checks.push({ name: 'issuer_trust', passed: true, message: 'Issuer is in trusted whitelist' });

  // ── STEP 6 & 7: Resolve issuer DID → verifikasi tanda tangan issuer (gunakan kid dari header) ──
  const issuerPublicKey = await resolveDIDPublicKey(issuerDID, issuerKid);
  checks.push({ name: 'did_resolution_issuer', passed: true, message: 'Issuer DID resolved' });
  const issuerPayload = await verifyJWTSignature(issuerJwt, issuerPublicKey);
  checks.push({ name: 'signature_vc', passed: true, message: 'Issuer SD-JWT signature valid' });

  // ── STEP 8: Validasi klaim temporal ──
  const now = Math.floor(Date.now() / 1000);
  const skew = verifierPolicy.maxClockSkewSeconds;

  if (typeof issuerPayload.nbf === 'number' && issuerPayload.nbf > now + skew) {
    throw new VPValidationError('SD-JWT belum berlaku (nbf)', 'SD_NBF');
  }
  if (typeof issuerPayload.exp === 'number' && issuerPayload.exp < now - skew) {
    throw new VPValidationError('SD-JWT sudah kadaluarsa (exp)', 'SD_EXPIRED');
  }
  checks.push({ name: 'time_window', passed: true, message: 'SD-JWT nbf/exp valid' });

  // ── Holder binding via Key Binding JWT ──
  let holderDID: string = (issuerPayload.sub as string) || '';

  if (kbJwt) {
    const rawKB = jwt.decode(kbJwt, { complete: true }) as { header: Record<string, unknown>; payload: Record<string, unknown> } | null;
    if (rawKB) {
      const kbPayload = rawKB.payload;
      // Ambil kid dari header KB-JWT untuk menemukan kunci holder yang tepat
      const kbKid = rawKB.header.kid as string | undefined;

      // Extract holder DID from KB-JWT iss
      const kbIss = kbPayload.iss as string | undefined;
      if (kbIss?.startsWith('did:')) holderDID = kbIss;

      // ── STEP 4: Cek nonce di KB-JWT (anti-replay) ──
      const kbNonce = kbPayload.nonce as string | undefined;
      if (verifierPolicy.requireNonceBinding && !kbNonce) {
        throw new VPValidationError('Nonce tidak ditemukan pada key-binding proof', 'NONCE_MISSING_IN_PROOF');
      }
      if (kbNonce && kbNonce !== expectedNonce) {
        throw new VPValidationError(
          `Nonce tidak cocok di KB-JWT: expected=${expectedNonce}, got=${kbNonce}`,
          'SD_NONCE_MISMATCH',
        );
      }
      checks.push({ name: 'nonce', passed: true, message: 'Nonce matches key-binding JWT' });

      if (verifierPolicy.requireAudienceMatch) {
        const expectedAudience = config.oid4vp.verifierClientId;
        const expectedCandidates = [expectedAudience, config.did.verifierId, config.did.domain];
        if (!audienceMatchesExpected(kbPayload.aud, expectedCandidates)) {
          throw new VPValidationError(
            `Audience KB-JWT tidak valid: expected=${expectedAudience}, got=${String(kbPayload.aud)}`,
            'STEP4_AUDIENCE_MISMATCH',
          );
        }
        checks.push({ name: 'audience', passed: true, message: 'Audience matches verifier client_id' });
      } else {
        checks.push({ name: 'audience', passed: true, message: 'Audience check skipped by policy' });
      }

      // ── STEP 3: Verifikasi tanda tangan KB-JWT (holder's key) ──
      if (holderDID.startsWith('did:')) {
        const holderPublicKey = await resolveDIDPublicKey(holderDID, kbKid);
        checks.push({ name: 'did_resolution_holder', passed: true, message: 'Holder DID resolved' });
        await verifyJWTSignature(kbJwt, holderPublicKey);
        checks.push({ name: 'signature_vp', passed: true, message: 'Key-binding signature valid' });
      }
    }
  } else {
    if (verifierPolicy.requireKeyBindingForSdJwt) {
      throw new VPValidationError('Key binding JWT wajib untuk SD-JWT', 'KEY_BINDING_INVALID');
    }
    // Tidak ada KB-JWT — cek nonce di issuer payload (beberapa wallet embed di sini)
    const embeddedNonce = issuerPayload.nonce as string | undefined;
    if (verifierPolicy.requireNonceBinding && !embeddedNonce) {
      throw new VPValidationError('Nonce tidak ditemukan pada SD-JWT proof', 'NONCE_MISSING_IN_PROOF');
    }
    if (embeddedNonce && embeddedNonce !== expectedNonce) {
      throw new VPValidationError(
        `Nonce tidak cocok: expected=${expectedNonce}, got=${embeddedNonce}`,
        'SD_NONCE_MISMATCH',
      );
    }
    checks.push({ name: 'nonce', passed: true, message: 'Nonce matches embedded SD-JWT nonce' });
  }

  const hasStatusField =
    typeof issuerPayload.credentialStatus === 'string'
    || typeof issuerPayload.credentialStatusId === 'string';
  if (!issuerPayload.iss || !holderDID || (!issuerPayload.nbf && !issuerPayload.iat) || !issuerPayload.exp || !hasStatusField) {
    throw new VPValidationError('Mandatory field SD-JWT tidak lengkap', 'CREDENTIAL_STRUCTURE');
  }
  checks.push({ name: 'mandatory_fields', passed: true, message: 'Mandatory SD-JWT fields present' });

  // ── STEP 9: Ekstrak disclosed claims dari disclosures ──
  const disclosedClaims: Record<string, unknown> = {};
  // Juga ambil top-level claims dari issuer payload (tidak di-_sd)
  const metaKeys = new Set(['iss', 'sub', 'iat', 'exp', 'nbf', 'jti', 'vct', 'cnf', '_sd', '_sd_alg', 'nonce']);
  for (const [key, val] of Object.entries(issuerPayload)) {
    if (!metaKeys.has(key)) disclosedClaims[key] = val;
  }
  // Full SD-JWT disclosure verification: recompute digest and match against _sd entries.
  let parsedDisclosures;
  try {
    parsedDisclosures = disclosureTokens.map((token) => parseDisclosureToken(token));
  } catch (error) {
    if (error instanceof SdJwtDisclosureError) {
      throw new VPValidationError(error.message, error.step);
    }
    throw error;
  }

  const disclosureVerification = verifyDisclosures(issuerPayload, parsedDisclosures);
  if (!disclosureVerification.ok) {
    throw new VPValidationError('Hash disclosure SD-JWT tidak valid', 'DISCLOSURE_HASH_MISMATCH');
  }
  checks.push({ name: 'disclosure_integrity', passed: true, message: 'Disclosure digest verification passed' });

  Object.assign(disclosedClaims, disclosureVerification.claims);

  const claims: VerifiedBPJSClaims = {
    holderDID,
    issuerDID,
    holderName: ((disclosedClaims.holderName ?? disclosedClaims.nama) as string | undefined),
    noBPJS: disclosedClaims.noBPJS as string | undefined,
    nik: disclosedClaims.nik as string | undefined,
    tanggalLahir: ((disclosedClaims.tanggalLahir ?? disclosedClaims.tanggal_lahir) as string | undefined),
    statusKepesertaan: disclosedClaims.statusKepesertaan as string | undefined,
    issuedAt: issuerPayload.nbf as number | undefined,
    expiresAt: issuerPayload.exp as number | undefined,
    ...disclosedClaims,
  };

  const statusId = (claims.credentialStatusId ?? claims.credentialStatus) as string | undefined;
  if (statusId) {
    const statusValue = await fetchCredentialStatusOnline(statusId, trustedIssuerRecord.endpoint);
    if (statusValue === 'REVOKED') {
      throw new VPValidationError('Credential telah direvoke', 'CREDENTIAL_STATUS_REVOKED');
    }
    if (statusValue === 'SUSPENDED') {
      throw new VPValidationError('Credential sedang disuspend', 'CREDENTIAL_STATUS_SUSPENDED');
    }
    if (statusValue === 'EXPIRED') {
      throw new VPValidationError('Credential status endpoint menyatakan expired', 'CREDENTIAL_STATUS_EXPIRED');
    }
    checks.push({ name: 'credential_status', passed: true, message: `Credential status is ${statusValue}` });
  }

  const requiredClaimSet = parseClaimKeysFromDefinition(presentationDefinition);
  const disclosurePolicy = enforceDisclosurePolicy(requiredClaimSet, disclosedClaims, verifierPolicy, 'sd-jwt');
  if (!disclosurePolicy.ok) {
    if (disclosurePolicy.missing.length > 0) {
      throw new VPValidationError(
        `Missing required claim: ${disclosurePolicy.missing.join(', ')}`,
        'MISSING_REQUIRED_CLAIM',
      );
    }

    if (disclosurePolicy.extras.length > 0) {
      throw new VPValidationError(
        `Oversharing claim terdeteksi: ${disclosurePolicy.extras.join(', ')}`,
        'OVERSHARING_DETECTED',
      );
    }
  }
  checks.push({ name: 'claim_policy', passed: true, message: 'Disclosure policy passed for SD-JWT' });

  return { claims, outcome: buildOutcome(checks) };
}
